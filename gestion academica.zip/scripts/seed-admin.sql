-- Seed admin user: jorge2003@gmail.com / pca2003
-- This uses Supabase's auth.users table directly with a hashed password
-- The trigger will auto-create the profile

-- First, check if the user already exists
DO $$
DECLARE
  admin_uid UUID;
BEGIN
  -- Check if user exists
  SELECT id INTO admin_uid FROM auth.users WHERE email = 'jorge2003@gmail.com';
  
  IF admin_uid IS NULL THEN
    -- Create the auth user with the specified password
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      confirmation_token,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'jorge2003@gmail.com',
      crypt('pca2003', gen_salt('bf')),
      now(),
      now(),
      now(),
      '',
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"full_name":"Jorge Admin","role":"admin"}'::jsonb,
      false
    )
    RETURNING id INTO admin_uid;

    -- Create identity for the user
    INSERT INTO auth.identities (
      id,
      user_id,
      provider_id,
      identity_data,
      provider,
      last_sign_in_at,
      created_at,
      updated_at
    ) VALUES (
      gen_random_uuid(),
      admin_uid,
      'jorge2003@gmail.com',
      jsonb_build_object('sub', admin_uid::text, 'email', 'jorge2003@gmail.com'),
      'email',
      now(),
      now(),
      now()
    );

    RAISE NOTICE 'Admin user created with id: %', admin_uid;
  ELSE
    -- Update the profile to admin if it exists
    UPDATE public.profiles SET role = 'admin', full_name = 'Jorge Admin' WHERE id = admin_uid;
    RAISE NOTICE 'Admin user already exists with id: %, profile updated to admin role', admin_uid;
  END IF;
END $$;
